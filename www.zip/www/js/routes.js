angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    
  

      .state('tabsController.bEGINNER', {
    url: '/page2',
    views: {
      'tab4': {
        templateUrl: 'templates/bEGINNER.html',
        controller: 'bEGINNERCtrl'
      }
    }
  })

  .state('tabsController.iNTERMEDIATE', {
    url: '/page3',
    views: {
      'tab2': {
        templateUrl: 'templates/iNTERMEDIATE.html',
        controller: 'iNTERMEDIATECtrl'
      }
    }
  })

  .state('tabsController.aDVANCED', {
    url: '/page4',
    views: {
      'tab3': {
        templateUrl: 'templates/aDVANCED.html',
        controller: 'aDVANCEDCtrl'
      }
    }
  })

  .state('tabsController', {
    url: '/page1',
    templateUrl: 'templates/tabsController.html',
    abstract:true
  })

  .state('tabsController.1', {
    url: '/page6',
    views: {
      'tab4': {
        templateUrl: 'templates/1.html',
        controller: '1Ctrl'
      }
    }
  })

  .state('tabsController.page9', {
    url: '/page9',
    views: {
      'tab4': {
        templateUrl: 'templates/page9.html',
        controller: 'page9Ctrl'
      }
    }
  })

  .state('tabsController.2', {
    url: '/page8',
    views: {
      'tab4': {
        templateUrl: 'templates/2.html',
        controller: '2Ctrl'
      }
    }
  })

  .state('tabsController.3', {
    url: '/page10',
    views: {
      'tab4': {
        templateUrl: 'templates/3.html',
        controller: '3Ctrl'
      }
    }
  })

  .state('4', {
    url: '/page11',
    templateUrl: 'templates/4.html',
    controller: '4Ctrl'
  })

  .state('tabsController.5', {
    url: '/page12',
    views: {
      'tab4': {
        templateUrl: 'templates/5.html',
        controller: '5Ctrl'
      }
    }
  })

  .state('tabsController.6', {
    url: '/page13',
    views: {
      'tab4': {
        templateUrl: 'templates/6.html',
        controller: '6Ctrl'
      }
    }
  })

  .state('tabsController.7', {
    url: '/page14',
    views: {
      'tab4': {
        templateUrl: 'templates/7.html',
        controller: '7Ctrl'
      }
    }
  })

  .state('tabsController.8', {
    url: '/page15',
    views: {
      'tab4': {
        templateUrl: 'templates/8.html',
        controller: '8Ctrl'
      }
    }
  })

  .state('tabsController.9', {
    url: '/page16',
    views: {
      'tab4': {
        templateUrl: 'templates/9.html',
        controller: '9Ctrl'
      }
    }
  })

  .state('tabsController.10', {
    url: '/page17',
    views: {
      'tab4': {
        templateUrl: 'templates/10.html',
        controller: '10Ctrl'
      }
    }
  })

  .state('tabsController.11', {
    url: '/page18',
    views: {
      'tab4': {
        templateUrl: 'templates/11.html',
        controller: '11Ctrl'
      }
    }
  })

  .state('tabsController.12', {
    url: '/page19',
    views: {
      'tab4': {
        templateUrl: 'templates/12.html',
        controller: '12Ctrl'
      }
    }
  })

  .state('tabsController.13', {
    url: '/page20',
    views: {
      'tab2': {
        templateUrl: 'templates/13.html',
        controller: '13Ctrl'
      }
    }
  })

  .state('tabsController.14', {
    url: '/page21',
    views: {
      'tab2': {
        templateUrl: 'templates/14.html',
        controller: '14Ctrl'
      }
    }
  })

  .state('tabsController.15', {
    url: '/page22',
    views: {
      'tab2': {
        templateUrl: 'templates/15.html',
        controller: '15Ctrl'
      }
    }
  })

  .state('tabsController.16', {
    url: '/page23',
    views: {
      'tab2': {
        templateUrl: 'templates/16.html',
        controller: '16Ctrl'
      }
    }
  })

  .state('tabsController.17', {
    url: '/page24',
    views: {
      'tab2': {
        templateUrl: 'templates/17.html',
        controller: '17Ctrl'
      }
    }
  })

  .state('tabsController.18', {
    url: '/page25',
    views: {
      'tab2': {
        templateUrl: 'templates/18.html',
        controller: '18Ctrl'
      }
    }
  })

  .state('tabsController.19', {
    url: '/page26',
    views: {
      'tab3': {
        templateUrl: 'templates/19.html',
        controller: '19Ctrl'
      }
    }
  })

  .state('tabsController.20', {
    url: '/page27',
    views: {
      'tab3': {
        templateUrl: 'templates/20.html',
        controller: '20Ctrl'
      }
    }
  })

  .state('tabsController.21', {
    url: '/page28',
    views: {
      'tab3': {
        templateUrl: 'templates/21.html',
        controller: '21Ctrl'
      }
    }
  })

  .state('tabsController.22', {
    url: '/page29',
    views: {
      'tab3': {
        templateUrl: 'templates/22.html',
        controller: '22Ctrl'
      }
    }
  })

  .state('tabsController.23', {
    url: '/page30',
    views: {
      'tab3': {
        templateUrl: 'templates/23.html',
        controller: '23Ctrl'
      }
    }
  })

$urlRouterProvider.otherwise('/page1/page2')

  

});